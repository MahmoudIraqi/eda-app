import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-completion-the-lab',
  templateUrl: './completion-the-lab.component.html',
  styleUrls: ['./completion-the-lab.component.css']
})
export class CompletionTheLabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
