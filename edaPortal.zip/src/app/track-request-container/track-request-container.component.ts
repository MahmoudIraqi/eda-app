import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-track-request-container',
  templateUrl: './track-request-container.component.html',
  styleUrls: ['./track-request-container.component.css']
})
export class TrackRequestContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
