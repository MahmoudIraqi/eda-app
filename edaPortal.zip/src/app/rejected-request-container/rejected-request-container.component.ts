import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rejected-request-container',
  templateUrl: './rejected-request-container.component.html',
  styleUrls: ['./rejected-request-container.component.css']
})
export class RejectedRequestContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
