import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-draft-requests-container',
  templateUrl: './draft-requests-container.component.html',
  styleUrls: ['./draft-requests-container.component.css']
})
export class DraftRequestsContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
