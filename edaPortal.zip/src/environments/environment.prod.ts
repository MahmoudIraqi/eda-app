export const environment = {
  production: true,
  apiURL: '/edaapi/api/',
  compareURL: '/compare/api/',
  // loginAPIURL: 'http://107.180.75.165:9067/api/Login/Comp'

  // loginAPIURL: 'http://196.46.22.220/APICompanyToken/api/Login/Comp'  // with CORS error
};
